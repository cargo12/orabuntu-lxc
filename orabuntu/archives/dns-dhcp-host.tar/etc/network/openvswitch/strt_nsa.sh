#!/bin/bash
#
# Manage the Ubuntu 16.04 LXC containerized nameserver
#
start() {
  exec lxc-start -n nsa > /dev/null 2>&1
}

stop() {
  exec lxc-stop -n nsa > /dev/null 2>&1
}

case $1 in
  start|stop) "$1" ;;
esac

