#!/bin/bash

clear

export DATEXT=`date +"%Y%m%d%H%M"`

sudo service multipath-tools stop > /dev/null 2>&1
sudo multipath -F

echo ''
echo "==============================================="
echo "List any existing multipath maps...            "
echo "==============================================="
echo ''

ls -l /dev/mapper

echo ''
echo "==============================================="
echo "Verify existing multipath maps removed...      "
echo "==============================================="
echo ''

if [ -e /etc/multipath.conf ]
then
sudo cp -p /etc/multipath.conf /etc/multipath.conf.$DATEXT
fi

sudo cp -p multipath.conf /etc/multipath.conf

sleep 2

sudo service multipath-tools start

sleep 2

clear

echo ''
echo "=============================================="
echo "List new multipath TGT LUN maps ...           "
echo "=============================================="
echo ''

ls -l /dev/mapper

echo ''
echo "=============================================="
echo "List multipath TGT LUNs completed.            "
echo "TGT SAN creation completed.                   "
echo "=============================================="
echo ''
